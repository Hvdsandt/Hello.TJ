﻿using System;

namespace Conditionals
{
    class Program
    {
        static void Main(string[] args)
        {

            bool justinHasBananas = true;
            if (justinHasBananas == true)
            {
                Console.WriteLine("Hey justin, can I have some bananas");
            }
            else // this is equivalent to: if (justinHasBananas == false)
            {
                Console.WriteLine("I'm disappointed that you don't have any bananas");
            }

        }
    }
}