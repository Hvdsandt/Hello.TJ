﻿using System;

namespace Conditionals3
{
    class Program
    {
        static void Main(string[] args)
        {
            char exit = 'n';

            while (exit == 'n')
            {
                // stock take
                int numberOfApples = 0;
                int numberOfBananas = 0;

                Console.Write("How many apples are in stock? ");
                string applesString = Console.ReadLine();

                Console.Write("How many bananas are in stock? ");
                string bananasString = Console.ReadLine();

                numberOfApples = Convert.ToInt32(applesString);
                numberOfBananas = Convert.ToInt32(bananasString);

                int lowStockLevelApples = 10;
                int lowStockLevelBananas = 15;

                int overStockLevelApples = 45;
                int overStockLevelBananas = 60;

                // MORE THAN/LESS THAN operator
                // > : MORE THAN
                // < : LESS THAN
                // >= : MORE THAN OR EQUALS (inclusive)
                // <= : LESS THAN OR EQUALS (exclusive)
                bool appleStockLow = (numberOfApples < lowStockLevelApples);
                if (appleStockLow)
                // equivalent: if (appleStockLow == true)
                {
                    Console.WriteLine("Order apples");
                }
                else if (numberOfApples > overStockLevelApples)
                {
                    Console.WriteLine("Discount apples. No reorder");
                }
                else
                {
                    Console.WriteLine("Apple stock levels normal. No reorder required.");
                }

                if (numberOfBananas < lowStockLevelBananas)
                {
                    Console.WriteLine("Order bananas");
                }
                else if (numberOfBananas > overStockLevelBananas)
                {
                    Console.WriteLine("Discount bananas. No reorder.");
                }
                else
                {
                    Console.WriteLine("Bananas stock levels normal. No reorder required.");
                }


                Console.Write("Do you want to exit? (y/n): ");
                exit = Console.ReadKey().KeyChar;
                Console.WriteLine();
            }
        }
    }
}